from django import forms
from django.contrib.auth.models import User
class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)


    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'


from django.contrib.auth.forms import UserCreationForm

class SignupForm(UserCreationForm):
    username =forms.CharField(max_length=50,help_text="")
    password1 = forms.CharField(label="Password",widget=forms.PasswordInput,max_length=20,min_length=8)
    email =forms.EmailField()

    def __init__(self, *args, **kwargs):
        super(SignupForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'

    # def clean_username(self):
    #     username = self.cleaned_data.get('username')
    #     if "" not in username:
    #         raise forms.ValidationError("Username not valid !")
    #     return username
from .models import StudentProfile
class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields =('image','name','dob','gender','about','address')

    dob=forms.CharField(widget=forms.TextInput(attrs={'type':'date'}))
    about=forms.CharField(widget=forms.Textarea(attrs={'rows':'2'}))
    address=forms.CharField(widget=forms.Textarea(attrs={'rows':'2'}))

    def __init__(self, *args, **kwargs):
        super(StudentProfileForm, self).__init__(*args, **kwargs)
        for visible in self.visible_fields():
            visible.field.widget.attrs['class'] = 'form-control'