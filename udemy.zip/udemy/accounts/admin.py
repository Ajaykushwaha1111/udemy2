from django.contrib import admin

# Register your models here.
from .models import StudentProfile

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user','age','address','joining_date','status')
    list_editable = ('age','address','status')
    list_filter = ('age','joining_date','status')