

from django.urls import path
from . import views as ac_views
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('login/', ac_views.login_view, name="login"),

    path('signup/', ac_views.signup_view, name="signup"),
    path('', ac_views.dashborad, name="dashboard"),
    path('logout/', ac_views.logout_view, name="logout"),
    path('profile/', ac_views.profile_view, name="profile"),
    path('profile_edit/', ac_views.profile_edit, name="profile_edit"),
    path('change_password/', ac_views.change_password, name="change_password"),
    path('password-reset/',
         auth_views.PasswordResetView.as_view(template_name='accounts/reset_password.html')
         ,name='password_reset'),
    path('password_reset/done/',
         auth_views.PasswordChangeDoneView.as_view(template_name='accounts/reset_password_done.html')
         ,name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(template_name='accounts/reset_password_confirm.html')
         ,name='password_reset_confirm'),

    path('password-reset-complete/',
         auth_views.PasswordResetCompleteView.as_view(template_name='accounts/reset_password_complete.html')
         ,name='password_reset_complete'),
]
