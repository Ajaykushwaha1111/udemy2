

from django.urls import path
from . import views
urlpatterns = [
    path('c/', views.all_courses_view, name="all_c"),
    path('s/', views.all_subject_view, name="all_sub"),
    path('onec/<slug>', views.one_courses_view, name="one_c"),
]
