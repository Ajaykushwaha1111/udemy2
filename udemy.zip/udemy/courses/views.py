from django.shortcuts import render,HttpResponse

# Create your views here.
from .models import Course,Subject,RecentViewCouse
def all_courses_view(request):
    c = Course.objects.filter(status=True).order_by('-id')
    if request.is_ajax():
        search_keyword =request.GET.get('search_keyword')
        if search_keyword:
            print(search_keyword)
            c=Course.objects.filter(status=True,title__startswith=search_keyword).order_by('-id')
    context ={
        'w':c
    }
    return render(request,'all_course.html',context)
from .models import Topic
def one_courses_view(request,slug=None):

    context=dict()
    if request.is_ajax():

        cid =request.GET.get('cid')
        c =Course.objects.get(id=cid)
        topics =Topic.objects.filter(course=c)
        rCourses =RecentViewCouse.objects.filter(status=True).order_by('-id')
        if request.user.is_authenticated:
            match_course =RecentViewCouse.objects.filter(course=c)
            if not match_course:
                RecentViewCouse.objects.create(user=request.user,course=c)
        context ={
            'course':c,
            'topics':topics,
            'rCourses':rCourses,
        }
    return render(request,'one_course.html',context)

def all_subject_view(request):
    c =Subject.objects.filter(status=True).order_by('-id')
    context ={
        'w':c
    }
    return render(request,'all_subject.html',context)
