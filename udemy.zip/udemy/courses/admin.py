from django.contrib import admin

# Register your models here.
from .models import Course,Topic,Subject

from django.contrib.auth.models import User
from import_export.admin import ImportExportModelAdmin

admin.site.unregister(User)
@admin.register(User)
class AdminExportImport(ImportExportModelAdmin):
    list_display = ('username', 'email')

@admin.register(Topic)
class TopicExportImport(ImportExportModelAdmin):
    list_display = ('name','status','content','datetime')
    list_filter = ('status','datetime')


class TopicInline(admin.TabularInline):
    model = Topic


class CousreIniline(admin.TabularInline):
    model = Course

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    inlines = [CousreIniline]
    list_display = ('name','status')


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    inlines = [TopicInline]
    list_display = ('title','image','subject','desc','status','price')
    list_display_links = ('title',)
    list_editable = ('subject','price','status')
    list_per_page = 2
    list_filter = ('subject','datetime')
    search_fields = ('title',)
    fields =  ('title','image','subject','desc','status','price')




